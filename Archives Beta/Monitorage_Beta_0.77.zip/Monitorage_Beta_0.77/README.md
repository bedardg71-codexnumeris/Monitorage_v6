# Système de Monitorage Pédagogique - Beta 0.77

**Date de publication :** 28 octobre 2025
**Version :** Beta 0.77 - Correctifs critiques

---

## ⚠️ CORRECTIFS CRITIQUES

**Cette version corrige deux bugs bloquants de Beta 0.75** :

### Bug #1 : Import de données corrompu (import-export.js)
- ❌ **Symptômes** : Erreurs `JSON.parse: unexpected character`
- ✅ **Corrigé** : Conversion JSON correcte avant sauvegarde dans localStorage (ligne 192)

### Bug #2 : Fonction manquante (groupe.js)
- ❌ **Symptômes** : Erreur `ajouterEtudiant is not defined` dans `groupe.js:887`
- ✅ **Corrigé** : Export de fonction inexistante commenté (ligne 887)

### 🔧 Action requise si vous aviez testé Beta 0.75 ou 0.76

Si vous avez déjà importé les données avec une version antérieure, vous devez **effacer votre localStorage** avant d'utiliser Beta 0.77 :

1. Ouvrir l'application dans votre navigateur
2. Ouvrir la console (F12 ou Cmd+Option+I sur Mac)
3. Taper : `localStorage.clear()`
4. Appuyer sur Entrée
5. Recharger la page (Cmd+R ou Ctrl+R)
6. Réimporter `donnees-demo.json`

---

## 📦 Contenu du package

### Fichiers principaux
- **`index 77 (correctifs critiques).html`** - Application complète (point d'entrée)
- **`donnees-demo.json`** - Package de démonstration complet
- **`etudiants-demo.txt`** - 30 étudiants groupe TEST
- **`etudiants-demo-groupe9999.txt`** - 30 étudiants groupe 9999
- **`README_DONNEES_DEMO.md`** - Guide détaillé des données de démonstration
- **`CLAUDE.md`** - Documentation technique pour développeurs
- **`js/`** - Tous les modules JavaScript (27 fichiers)

### Données de démonstration incluses

Le fichier `donnees-demo.json` contient :

✅ **30 étudiants** avec diversité culturelle (80% québécois, 20% multiculturels)
✅ **9 productions** configurées (5 sommatives + 4 artefacts portfolio)
✅ **Grille SRPNF** complète (Structure, Rigueur, Plausibilité, Nuance, Français)
✅ **Échelle IDME** (Insuffisant, Développement, Maîtrisé, Étendu)
✅ **Cartouche de rétroaction** "A2 Description d'un personnage" (16 commentaires)
✅ **Calendrier complet** du trimestre (15 semaines, 124 jours)
✅ **Horaire** de cours (Lundi 13h-16h)
✅ **3 présences** saisies avec jetons par étudiant

---

## 🚀 Démarrage rapide

### Option 1 : Import complet (recommandé pour débuter)

1. **Ouvrir** `index 77 (correctifs critiques).html` dans votre navigateur
2. **Aller** dans Réglages → Import/Export
3. **Cliquer** sur «📥 Importer des données»
4. **Sélectionner** le fichier `donnees-demo.json`
5. **Confirmer** l'import
6. **Recharger** la page si demandé

✨ **Voilà !** Vous avez maintenant 30 étudiants avec toutes leurs données.

### Option 2 : Configuration manuelle progressive

1. **Ouvrir** l'application
2. **Aller** dans Réglages → Trimestre (configurer dates et horaire)
3. **Aller** dans Réglages → Groupe → Import/Export
4. **Importer** `etudiants-demo.txt` ou `etudiants-demo-groupe9999.txt`
5. **Configurer** vos productions dans Matériel → Productions
6. **Importer** les grilles, échelles et cartouches depuis Matériel

---

## ✨ Correctifs de cette version

### 🐛 Correctif #1 : Import de données (import-export.js)

**Problème** : Les objets JavaScript n'étaient pas convertis en JSON avant sauvegarde dans localStorage.

**Code corrigé** (lignes 191-198) :
```javascript
Object.keys(donneesImportEnAttente).forEach(cle => {
    // IMPORTANT : Convertir en JSON string avant de sauvegarder
    const valeur = typeof donneesImportEnAttente[cle] === 'string'
        ? donneesImportEnAttente[cle]
        : JSON.stringify(donneesImportEnAttente[cle]);
    localStorage.setItem(cle, valeur);
    nbCles++;
});
```

### 🐛 Correctif #2 : Export fonction inexistante (groupe.js)

**Problème** : La ligne 887 tentait d'exporter `ajouterEtudiant` qui n'existe pas.

**Code corrigé** (ligne 887) :
```javascript
// window.ajouterEtudiant = ajouterEtudiant; // FIXME: fonction n'existe pas
```

**Note** : La fonction `addStudent()` existe et peut être utilisée à la place si nécessaire.

---

## 📚 Explorer l'application

### 1. Dépistage précoce (Tableau de bord)

1. **Cliquer** sur l'icône 📊 Tableau de bord
2. Observer les **indicateurs globaux** (assiduité, complétion, performance)
3. Identifier les **étudiants à risque** (barres rouges)
4. Consulter les **recommandations RàI** (réponse à l'intervention)

### 2. Profil étudiant détaillé

1. **Cliquer** sur un nom d'étudiant dans le tableau de bord
2. Explorer les **3 sections** :
   - **Suivi de l'apprentissage** : Indices R, RàI, échelle de risque visuelle
   - **Développement des habiletés** : Performance SRPNF par critère
   - **Mobilisation** : Assiduité, complétion, historique des artefacts
3. **Naviguer** entre étudiants avec les flèches ⬅️ ➡️

### 3. Gestion des présences

1. **Aller** dans Présences → Saisie
2. Voir les **3 présences déjà saisies** (dates avec jetons)
3. Essayer d'**ajouter une nouvelle séance** pour voir le système de jetons en action
4. Observer le calcul automatique de l'**indice d'assiduité (A)**

### 4. Évaluations et productions

1. **Aller** dans Évaluations → Productions
2. Voir les **9 productions** déjà configurées
3. **Cliquer** sur une production pour voir les évaluations par étudiant
4. Observer les **scores SRPNF** et calculs automatiques

### 5. Rétroactions automatisées

1. **Aller** dans Matériel → Rétroactions
2. Voir la **cartouche "A2 Description d'un personnage"**
3. Explorer les **16 commentaires** organisés par critère (4) et niveau IDME (4)
4. Tester l'**export JSON** et l'**import .txt**

### 6. Section Aide complète

1. **Cliquer** sur l'icône ❓ Aide
2. Explorer les **5 sous-sections** :
   - Introduction au système
   - Configuration initiale
   - Utilisation hebdomadaire
   - Consultation des profils
   - Référence technique (FAQ, Glossaire)

---

## 🔧 Configuration requise

- **Navigateur moderne** : Safari, Chrome, Firefox, Edge (versions récentes)
- **JavaScript activé**
- **localStorage disponible** (minimum 5-10 Mo libres)
- **Connexion internet** : NON requise (application 100% autonome)

---

## 📖 Documentation complète

- **`README_DONNEES_DEMO.md`** : Guide détaillé des données de démonstration
- **`CLAUDE.md`** : Documentation technique pour développeurs et architecture du projet
- **Section Aide** (dans l'application) : Documentation utilisateur complète avec :
  - Guide de démarrage rapide
  - Workflows recommandés
  - FAQ (13 questions)
  - Glossaire (45 termes)

---

## 🐛 Signaler un problème

Si vous rencontrez un problème :

1. **Vérifier la console** navigateur (F12 ou Cmd+Option+I)
2. **Consulter** la section Aide → Référence technique → FAQ
3. **Noter** les messages d'erreur exacts
4. **Contacter** : labo@codexnumeris.org

### Problèmes résolus dans Beta 0.77 :
✅ Import de données corrompu (JSON.stringify manquant)
✅ Erreur `ajouterEtudiant is not defined` (export fonction inexistante)
✅ Application ne charge pas après import

---

## 📝 Licence et crédits

### Double licence

- **Code source** : GNU General Public License v3 (GPL v3)
- **Contenu pédagogique** : Creative Commons Attribution-ShareAlike 4.0 (CC BY-SA 4.0)

### Crédits

**Créé par :** Grégoire Bédard
**Institution :** Cégep de Drummondville
**Ressources :** https://codexnumeris.org/apropos
**Contact :** labo@codexnumeris.org

### Publications

Articles publiés dans la *Revue Pédagogie collégiale* :
- Printemps-été 2024
- Hiver 2025

---

## 🎓 À propos du projet

### Objectif pédagogique

Système de monitorage pédagogique conçu pour le suivi des apprentissages au collégial. Permet de :

- 🔍 **Dépister précocement** les élèves en difficulté via indices prédictifs (A-C-P-R)
- 📊 **Générer des diagnostics** automatisés basés sur des données objectives
- 💬 **Personnaliser la rétroaction** via cartouches réutilisables
- 📈 **Suivre la progression** longitudinale des étudiants
- 🔬 **Comparer des pratiques** d'évaluation (sommative vs alternative)
- 🤝 **Collaborer** entre enseignants via partage de matériel pédagogique

### Principe fondamental

**Faire mentir les prédictions de risque par des interventions proactives !**

Le système identifie les étudiants à risque le plus tôt possible pour permettre une intervention avant qu'il ne soit trop tard. L'objectif n'est pas de prédire l'échec, mais de le prévenir.

### Architecture technique

- **100% autonome** : Fonctionne hors-ligne, aucun serveur requis
- **Données locales** : Tout stocké dans le navigateur (localStorage)
- **Aucune dépendance** : JavaScript pur (ES6+), HTML5, CSS3
- **Respect de la vie privée** : Aucune donnée n'est transmise à l'extérieur

---

## 🚀 Prochaines étapes

Après avoir exploré les données de démonstration, vous pouvez :

1. **Effacer les données démo** : Réglages → Import/Export → Réinitialiser
2. **Configurer votre cours** : Réglages → Cours (code, titre, session)
3. **Importer vos étudiants** : Préparez un fichier .txt (voir README_DONNEES_DEMO.md)
4. **Créer vos productions** : Matériel → Productions
5. **Personnaliser vos cartouches** : Matériel → Rétroactions
6. **Commencer le monitorage** : Présences → Saisie

---

**Bons tests !** 🚀

*Pour toute question ou suggestion d'amélioration, n'hésitez pas à nous contacter.*
